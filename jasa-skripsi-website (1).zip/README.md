# Jasa Pembuatan Skripsi Website

Repository ini berisi website statis untuk layanan:
- Jasa pembuatan skripsi
- Tugas kuliah
- Penurunan plagiasi
- Pembuatan buku

## Cara Publish ke GitHub Pages
1. Buat repository baru di GitHub bernama **jasa-skripsi-website**
2. Upload semua file dari folder ini
3. Masuk ke:
   Settings → Pages
4. Pada "Build and Deployment", pilih:
   - Source: **Deploy from branch**
   - Branch: **main**
   - Folder: **root**
5. Klik **Save**
6. Website akan tampil di:
   `https://wahyuhasby.github.io/jasa-skripsi-website`
